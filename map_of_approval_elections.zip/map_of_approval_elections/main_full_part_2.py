

import mapel
import matplotlib.pyplot as plt
import itertools

from scipy.stats import stats


if __name__ == "__main__":


    # COMPARE METRICS

    experiment_id = 'approval/hamming'
    num_voters = 50.

    names = [
        'hamming',
        'l1-approvalwise',
    ]

    all_distances = {}

    ctr = 0
    for name in names:
        print(name)
        experiment = mapel.prepare_experiment(experiment_id=experiment_id, shift=True,
                                              instance_type='approval', distance_id=name)
        if name in ['l1-approvalwise']:
            experiment.compute_distances(distance_id=name, printing=False)
        all_distances[name] = experiment.distances

    line = ""

    print("=======")
    for name_1, name_2 in itertools.combinations(names, 2):
        ctr += 1

        values_x = []
        values_y = []
        empty_x = []
        empty_y = []
        for e1, e2 in itertools.combinations(all_distances[name_1], 2):

            if 'moving' in e1 or 'moving' in e2 or 'vcr' in e1 or 'vcr' in e2:
                continue

            values_x.append(all_distances[name_1][e1][e2] / num_voters)
            values_y.append(all_distances[name_2][e1][e2])

        fig = plt.figure(figsize=(6.4, 6.4))

        ax = fig.add_subplot()

        ax.scatter(values_x, values_y, s=4, alpha=0.01, color='purple')

        ctr_eq = 0
        ctr_alm = 0
        ctr_dif = 0
        for a, b in zip(values_x, values_y):
            if a == b:
                ctr_eq += 1
            elif b - 0.00001 < a < b + 0.00001:
                ctr_alm += 1
            elif a - 0.00001 < b < a + 0.00001:
                ctr_alm += 1
            else:
                ctr_dif += 1

        print(ctr_eq, ctr_alm, ctr_dif)
        print((ctr_eq + ctr_alm) / (ctr_eq + ctr_alm + ctr_dif))

        pear = round(stats.pearsonr(values_x, values_y)[0], 3)
        print('PCC', pear)

        plt.xlabel('Hamming', size=24)
        plt.ylabel('$\ell_1$-Approvalwise', size=24)
        plt.xticks(fontsize=16)
        plt.yticks(fontsize=16)
        saveas = f'images/correlation/corr_{name_1}_{name_2}'
        plt.savefig(saveas, bbox_inches='tight', dpi=250)
        plt.show()
