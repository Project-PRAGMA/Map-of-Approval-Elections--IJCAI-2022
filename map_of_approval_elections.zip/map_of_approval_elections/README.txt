"How to Sample Approval Elections?"
# 7573
====================================================================

It suffices to run main_mini.py to get the final results:
python main_mini.py

'Experiments' folder contains all the needed data.

====================================================================

To repeat all the experiments from the very beginning
it requires installation of a large number of packages, like: Gurobi etc.

To repeat full experiment, first run:
python main_full_part_1.py

compile main_hamming file:
g++ -std=c++2a -o main_hamming.out main_hamming.cpp

run main_hamming file:
./main_hamming.out 363 10 50

compile post file:
g++ -std=c++2a -o post.out post.cpp

run post file:
./post.out 1 approval/hamming 363 spear

run python file:
python main_full_part_2.py


