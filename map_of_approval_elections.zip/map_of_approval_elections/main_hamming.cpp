
#include <iostream>
#include <cstdlib>
#include <vector>
#include <string>
#include <fstream>
#include <algorithm>
#include <utility>
#include <bitset>
#include <filesystem>

namespace fs = std::__fs::filesystem;
using namespace std;


#define num_elections 2
#define num_candidates 8
#define num_voters 50


#define BIG 100000
typedef int row;
typedef int col;
typedef int cost;
#if !defined TRUE
#define	 TRUE		1
#endif
#if !defined FALSE
#define  FALSE		0
#endif
typedef int boolean;

/*This function is the jv shortest augmenting path algorithm to solve the assignment problem*/
cost lap(int dim,
         cost **assigncost,
         col *rowsol,
         row *colsol,
         cost *u,
         cost *v)

// input:
// dim        - problem size
// assigncost - cost matrix

// output:
// rowsol     - column assigned to row in solution
// colsol     - row assigned to column in solution
// u          - dual variables, row reduction numbers
// v          - dual variables, column reduction numbers

{
    boolean unassignedfound;
    row  i, imin, numfree = 0, prvnumfree, f, i0, k, freerow, *pred, *free;
    col  j, j1, j2, endofpath, last, low, up, *collist, *matches;
    cost min, h, umin, usubmin, v2, *d;

    free = new row[dim];       // list of unassigned rows.
    collist = new col[dim];    // list of columns to be scanned in various ways.
    matches = new col[dim];    // counts how many times a row could be assigned.
    d = new cost[dim];         // 'cost-distance' in augmenting path calculation.
    pred = new row[dim];       // row-predecessor of column in augmenting/alternating path.

    // init how many times a row will be assigned in the column reduction.
    for (i = 0; i < dim; i++)
        matches[i] = 0;

    // COLUMN REDUCTION
    for (j = dim;j--;) // reverse order gives better results.
    {
        // find minimum cost over rows.
        min = assigncost[0][j];
        imin = 0;
        for (i = 1; i < dim; i++)
            if (assigncost[i][j] < min)
            {
                min = assigncost[i][j];
                imin = i;
            }
        v[j] = min;
        if (++matches[imin] == 1)
        {
            // init assignment if minimum row assigned for first time.
            rowsol[imin] = j;
            colsol[j] = imin;
        }
        else if(v[j]<v[rowsol[imin]]){
            int j1 = rowsol[imin];
            rowsol[imin] = j;
            colsol[j] = imin;
            colsol[j1] = -1;
        }
        else
            colsol[j] = -1;        // row already assigned, column not assigned.
    }

    // REDUCTION TRANSFER
    for (i = 0; i < dim; i++)
        if (matches[i] == 0)     // fill list of unassigned 'free' rows.
            free[numfree++] = i;
        else
        if (matches[i] == 1)   // transfer reduction from rows that are assigned once.
        {
            j1 = rowsol[i];
            min = BIG;
            for (j = 0; j < dim; j++)
                if (j != j1)
                    if (assigncost[i][j] - v[j] < min)
                        min = assigncost[i][j] - v[j];
            v[j1] = v[j1] - min;
        }

    //   AUGMENTING ROW REDUCTION
    int loopcnt = 0;           // do-loop to be done twice.
    do
    {
        loopcnt++;

        //     scan all free rows.
        //     in some cases, a free row may be replaced with another one to be scanned next.
        k = 0;
        prvnumfree = numfree;
        numfree = 0;             // start list of rows still free after augmenting row reduction.
        while (k < prvnumfree)
        {
            i = free[k];
            k++;

            //       find minimum and second minimum reduced cost over columns.
            umin = assigncost[i][0] - v[0];
            j1 = 0;
            usubmin = BIG;
            for (j = 1; j < dim; j++)
            {
                h = assigncost[i][j] - v[j];
                if (h < usubmin) {
                    if (h >= umin) {
                        usubmin = h;
                        j2 = j;
                    } else {
                        usubmin = umin;
                        umin = h;
                        j2 = j1;
                        j1 = j;
                    }
                }
            }

            i0 = colsol[j1];
            if (umin < usubmin)
                //         change the reduction of the minimum column to increase the minimum
                //         reduced cost in the row to the subminimum.
                v[j1] = v[j1] - (usubmin - umin);
            else                   // minimum and subminimum equal.
            if(i0 > -1)  // minimum column j1 is assigned.
            {
                //           swap columns j1 and j2, as j2 may be unassigned.
                j1 = j2;
                i0 = colsol[j2];
            }

            //       (re-)assign i to j1, possibly de-assigning an i0.
            rowsol[i] = j1;
            colsol[j1] = i;

            if(i0 > -1) {  // minimum column j1 assigned earlier.
                if (umin < usubmin)
                    //           put in current k, and go back to that k.
                    //           continue augmenting path i - j1 with i0.
                    free[--k] = i0;
                else
                    //           no further augmenting reduction possible.
                    //           store i0 in list of free rows for next phase.
                    free[numfree++] = i0;
            }
        }
    }
    while (loopcnt < 2);       // repeat once.

    // AUGMENT SOLUTION for each free row.
    for (f = 0; f < numfree; f++)
    {
        freerow = free[f];       // start row of augmenting path.

        // Dijkstra shortest path algorithm.
        // runs until unassigned column added to shortest path tree.
        for(j = dim;j--;)
        {
            d[j] = assigncost[freerow][j] - v[j];
            pred[j] = freerow;
            collist[j] = j;        // init column list.
        }

        low = 0; // columns in 0..low-1 are ready, now none.
        up = 0;  // columns in low..up-1 are to be scanned for current minimum, now none.
        // columns in up..dim-1 are to be considered later to find new minimum,
        // at this stage the list simply contains all columns
        unassignedfound = FALSE;
        do
        {
            if (up == low)         // no more columns to be scanned for current minimum.
            {
                last = low - 1;

                // scan columns for up..dim-1 to find all indices for which new minimum occurs.
                // store these indices between low..up-1 (increasing up).
                min = d[collist[up++]];
                for (k = up; k < dim; k++)
                {
                    j = collist[k];
                    h = d[j];
                    if (h <= min)
                    {
                        if (h < min)     // new minimum.
                        {
                            up = low;      // restart list at index low.
                            min = h;
                        }
                        // new index with same minimum, put on undex up, and extend list.
                        collist[k] = collist[up];
                        collist[up++] = j;
                    }
                }
                // check if any of the minimum columns happens to be unassigned.
                // if so, we have an augmenting path right away.
                for (k = low; k < up; k++)
                    if (colsol[collist[k]] < 0)
                    {
                        endofpath = collist[k];
                        unassignedfound = TRUE;
                        break;
                    }
            }

            if (!unassignedfound)
            {
                // update 'distances' between freerow and all unscanned columns, via next scanned column.
                j1 = collist[low];
                low++;
                i = colsol[j1];
                h = assigncost[i][j1] - v[j1] - min;

                for (k = up; k < dim; k++)
                {
                    j = collist[k];
                    v2 = assigncost[i][j] - v[j] - h;
                    if (v2 < d[j])
                    {
                        pred[j] = i;
                        if (v2 == min) {   // new column found at same minimum value
                            if (colsol[j] < 0) {
                                // if unassigned, shortest augmenting path is complete.
                                endofpath = j;
                                unassignedfound = TRUE;
                                break;
                            }
                                // else add to list to be scanned right away.
                            else {
                                collist[k] = collist[up];
                                collist[up++] = j;
                            }
                        }
                        d[j] = v2;
                    }
                }
            }
        }
        while (!unassignedfound);

        // update column prices.
        for( k = last+1;k--;)
        {
            j1 = collist[k];
            v[j1] = v[j1] + d[j1] - min;
        }

        // reset row and column assignments along the alternating path.
        do
        {
            i = pred[endofpath];
            colsol[endofpath] = i;
            j1 = endofpath;
            endofpath = rowsol[i];
            rowsol[i] = j1;
        }
        while (i != freerow);
    }

    // calculate optimal cost.
    cost lapcost = 0;
//  for (i = 0; i < dim; i++)
    for(i = dim;i--;)
    {
        j = rowsol[i];
        u[i] = assigncost[i][j] - v[j];
        lapcost = lapcost + assigncost[i][j];
    }

    // free reserved memory.
    delete[] pred;
    delete[] free;
    delete[] collist;
    delete[] matches;
    delete[] d;
    return lapcost;
}


vector<string> NAMES;

std::vector<std::vector<bitset<num_candidates> > > read_electionFromApp(string exp, int e, int n, int m) {

    using recursive_directory_iterator = fs::recursive_directory_iterator;

    std::vector<std::vector<bitset<num_candidates> > > elections;
    string pref = "./experiments/" + exp + "/elections/";
    string suf = ".app";

    vector<string> paths;

    for (const auto& dirEntry : recursive_directory_iterator(pref)) {
        paths.push_back(dirEntry.path());

        string name = dirEntry.path();

        std::string::size_type i = name.find(pref);
        if (i != std::string::npos)
            name.erase(i, pref.length());

        i = name.find(suf);
        if (i != std::string::npos)
            name.erase(i, suf.length());

        NAMES.push_back(name);
    }

    std::cout << pref << std::endl;
    for (int t = 0; t < e; t++) {
        string path = paths[t];
        cout << path << endl;
        cout << NAMES[t] << endl;

        string line;
        std::vector<string> myLines;
        std::vector<bitset<num_candidates>> election;
        ifstream myfile(path);
        int ctr = 0;
        if (myfile.is_open()) {
            while (getline(myfile, line)) {
                ctr++;
                if (ctr >= num_candidates+4) {
                    line.erase(std::remove(line.begin(), line.end(), '{'), line.end());
                    line.erase(std::remove(line.begin(), line.end(), '}'), line.end());
                    line.erase(std::remove(line.begin(), line.end(), ' '), line.end());
                    line += ',';



                    string segment;
                    std::vector<int> input;
                    std::string delimiter = ",";
                    size_t pos = 0;
                    std::string token;
                    int tmp = 0;
                    while ((pos = line.find(delimiter)) != std::string::npos) {
                        token = line.substr(0, pos);
                        if(token.length() == 0){
                            break;
                        }
                        input.push_back(stoi(token));
                        line.erase(0, pos + delimiter.length());
                        tmp++;
                    }

                    int freq = input[0];
                    bitset<num_candidates> set_vote;
                    std::string str_vote;
                    for(int i=0;i<num_candidates;i++){
                        str_vote += "0";
                    }


                    for (int i = 1; i < tmp; i++) {
                        str_vote[input[i]] = '1';
                    }


                    bitset<num_candidates> bin_vote(str_vote);



                    for (int i = 0; i < freq; i++) {
                       election.push_back(bin_vote);
                    }
                }

            }
            myfile.close();
        }
        elections.push_back(election);
    }

    return elections;
}


int hammingDistance_election(int n,int m, pair<std::vector<bitset<num_candidates> >,std::vector<bitset<num_candidates>> > elp){
    int min_dist=2*m*m*n;
    int* mapping = new int [m];
    col *rowsol;
    row *colsol;
    cost *u;
    cost *v;
    rowsol = new col[n];
    colsol = new row[n];
    u = new cost[n];
    v = new cost[n];
    int** costMatrix;
    costMatrix = new int*[n];
    for(int t=0;t<n;t++){
        costMatrix[t]  =  new int[n];
    }

    int** e1mapped_reversed;
    int** e2reversed;
    e1mapped_reversed = new int*[n];
    e2reversed = new int*[n];
    for(int t=0;t<n;t++){
        e1mapped_reversed[t]  =  new int[m];
        e2reversed[t]  =  new int[m];
    }

    for(int i=0; i<m; i++){mapping[i]=i;}
    do {
        for(int t=0; t<n; t++){

            bitset<num_candidates> x = std::get<0>(elp)[t];
            bitset<num_candidates> mapped_x;
            for(int q=0;q<num_candidates;q++) {
                mapped_x[q] = x[mapping[q]];
            }

            for(int j=0; j<n; j++){
                  costMatrix[t][j] = (mapped_x^std::get<1>(elp)[j]).count();
            }
        }

        int dist = lap(n,costMatrix, rowsol, colsol, u, v);
        if(dist<min_dist){min_dist=dist;}
    } while ( std::next_permutation(mapping,mapping+m) );
    delete[] mapping;
    delete[] rowsol;
    delete[] colsol;
    delete[] u;
    delete[] v;
    for( int i = 0 ; i < n ; i++ )
        {
            delete[] costMatrix[i];
            delete[] e1mapped_reversed[i];
            delete[] e2reversed[i];
        }
    delete[] costMatrix;
    delete[] e1mapped_reversed;
    delete[] e2reversed;
    return min_dist;

}




int main(int argc, char* argv[]) {

    int id_cur_thread=0;
    int number_threads=1;

    string exp="approval/hamming";
    int e=strtol(argv[1], nullptr, 0);//num_elections;
    int m=strtol(argv[2], nullptr, 0);//num_candidates;
    int n=strtol(argv[3], nullptr, 0);//num_voters;
//    int e=num_elections;
//    int m=num_candidates;
//    int n=num_voters;
    bool swap;
    bool dis;
    string modus="spear";
    if(modus=="swap"){
        swap=true;
    }
    else if(modus=="spear"){
        swap=false;
    }else if(modus=="discrete"){
        dis=true;
    }else{
        cout<<"Unknown distance metric"<<endl;
    }
    cout<<"THREAD ID "<<id_cur_thread<<"/"<<number_threads-1<<endl;

    uint8_t* swap_look;
    cout<<"Build lookup"<<endl;
//    if(swap){
//        swap_look=prec_map(m);}
    cout<<"Build election pairs"<<endl;
    std::vector<std::vector<bitset<num_candidates> > > elections = read_electionFromApp(exp, e, n, m);
    int len=0;
    std::vector<pair<pair<int,int>, pair<std::vector<bitset<num_candidates>  >, std::vector<bitset<num_candidates> > > > > full_election_pairs;
    for(int i=0; i<e; i++){
        for(int j=i+1; j<e; j++){
            pair<std::vector<bitset<num_candidates>  >, std::vector<bitset<num_candidates> > > election_pair=std::make_pair(elections[i],elections[j]);
            pair<int,int> id_pair= std::make_pair(i,j);
            full_election_pairs.push_back(std::make_pair(id_pair,election_pair));
            len=len+1;
        }
    }
    int basic_batchsize = len/number_threads;
    int remaining=len-number_threads*basic_batchsize;
    int start_id=0;
    int end_id=0;
    int batch_size=0;
    if(id_cur_thread>=remaining){
        start_id=remaining*(basic_batchsize+1)+(id_cur_thread-remaining)*basic_batchsize;
        end_id= start_id+basic_batchsize;
        batch_size=basic_batchsize;
    }
    else{
        start_id=id_cur_thread*(basic_batchsize+1);
        end_id= start_id+basic_batchsize+1;
        batch_size=basic_batchsize+1;
    }
    cout<<start_id<<endl;
    cout<<end_id<<endl;
    std::vector<pair<pair<int,int>, pair<std::vector<bitset<num_candidates>  >, std::vector<bitset<num_candidates> > > > >::const_iterator first = full_election_pairs.begin() + start_id;
    std::vector<pair<pair<int,int>, pair<std::vector<bitset<num_candidates>  >, std::vector<bitset<num_candidates> > > > >::const_iterator last = full_election_pairs.begin() + end_id;
    std::vector<pair<pair<int,int>, pair<std::vector<bitset<num_candidates>  >, std::vector<bitset<num_candidates> > > > > election_pairs (first, last);

    cout<<"Compute distances"<<endl;
    string path =  "./experiments/" + exp + "/distances/"+modus+"_"+to_string(id_cur_thread)+"_"+to_string(number_threads)+".txt";
    ofstream myfile;
    myfile.open (path);
    int distance;
    for (int i=0; i< batch_size; i++){
        int f=std::get<0>(std::get<0>(election_pairs[i]));
        int s=std::get<1>(std::get<0>(election_pairs[i]));
        cout <<"test: " <<  NAMES[f] << " " << NAMES[s] << endl;
        if(NAMES[f].find("1D") != string::npos or NAMES[s].find("1D") != string::npos or NAMES[f].find("2D") != string::npos or NAMES[s].find("2D") != string::npos){
            distance=hammingDistance_election(n,m,std::get<1>(election_pairs[i]));
            myfile<<NAMES[f]<<";"<<NAMES[s]<<";" << distance << ";0"<<endl;
        }

    }
    myfile.close();
    return 0;
}

