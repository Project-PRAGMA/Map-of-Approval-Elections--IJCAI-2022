
from matplotlib.transforms import Bbox
import math

import mapel
import matplotlib.pyplot as plt
import itertools

from scipy.stats import stats


def normalizing_function_pav(shade):
    if shade > 1500:
        shade = 1500.
    shade = math.log(shade) / math.log(1500)
    print(shade)
    return shade


def normalizing_function_coh_groups(shade):
    shade -= 0.5
    if shade <= 0.:
        shade = 0.
    shade *= 2
    return shade


if __name__ == "__main__":

    names = [
        'resampling',
        'noise_model',
        'truncated_urn',
        'disjoint',
        'pabulib',
        'euclidean'
    ]

    NICE_NAME = {
        'resampling': '(a) Resampling Model',
        'noise_model': '(b) Noise Model',
        'truncated_urn': '(c) Truncated Urn Model',
        'disjoint': '(b) Disjoint Model',
        'pabulib': '(d) Pabulib',
        'euclidean': '(a) Euclidean Model',
    }

    distance_id = 'l1-approvalwise'
    for name in names:
        print(name)

        experiment_id = f'final_egg/{name}'
        experiment = mapel.prepare_experiment(experiment_id=experiment_id,
                                              instance_type='approval', clean=False,
                                              distance_id=distance_id)
        # PREPARE MAP

        experiment.prepare_elections()
        experiment.compute_distances(distance_id=distance_id, printing=False)
        experiment.embed(algorithm='spring', num_iterations=2000)
        experiment.print_map(
            saveas=f'final_egg/raw_maps/{name}_{distance_id}',
            adjust=True, show=True,

            title=NICE_NAME[name], title_pos=0.075, legend=False,
            shading=True, bbox_inches=Bbox([[0 + 1.3, 0.], [6.4 - 1.3, 6.4-0.7]]),

            # legend=True, legend_pos=(0.5, -0.05),
            # shading=True, bbox_inches=Bbox([[0 + 1.3, -2.], [6.4 - 1.3, 6.4-0.7]]),

            # legend=False,
            # shading=True, bbox_inches=Bbox([[0 + 1.3, 0.7], [6.4 - 1.3, 6.4 - 0.7]]),

            textual=['IC 0.5', 'ID 0.5', 'empty', 'full'],
        )

        # FEATURE 1

        feature_id = 'max_approval_score'
        title = 'max. approval score'
        experiment.compute_feature(feature_id=feature_id)

        experiment.print_map(
            feature_id=feature_id, column_id='value', adjust=True, rounding=0,
            saveas=f'final_egg/features/{feature_id}/{name}_{distance_id}_{feature_id}',
            title=title, title_size=24,
            show=False, legend=False,
            bbox_inches=Bbox([[0 + 1.25, 0.5], [6.4 - 1.25, 6.4]]),
            ms=40, feature_labelsize=20,
            xticklabels=['0', '.2', '.4', '.6', '.8', '1.'],
            # ticks_pos=[0.05, 0.23, 0.41, 0.59, 0.77, 0.95],
            cmap=mapel.custom_div_cmap(
                colors=["green", "lightgreen", "yellow", "orange",
                        "red", "purple", "orchid", "dodgerblue", "blue", "darkblue", "black"],
                num_colors=101)
        )

        # FEATURE 2

        feature_id = 'justified_ratio'
        title = 'voters in coh. groups'
        feature_params = {'committee_size': 10}
        experiment.compute_feature(feature_id=feature_id, feature_params=feature_params)

        experiment.print_map(
            feature_id=feature_id, column_id='value', adjust=True,
            saveas=f'final_egg/features/{feature_id}/{name}_{distance_id}_{feature_id}',
            title=title, title_size=24,
            show=False, legend=False,
            bbox_inches=Bbox([[0 + 1.25, 0.5], [6.4 - 1.25, 6.4]]),
            ms=40, feature_labelsize=20,
            xticklabels=['$\leq$.5', '.6', '.7', '.8', '.9', '1.'],
            cmap=mapel.custom_div_cmap(
                colors=["green", "lightgreen", "yellow", "orange",
                        "red", "purple", "orchid", "dodgerblue", "blue", "darkblue", "black"],
                num_colors=101),
            normalizing_func=normalizing_function_coh_groups,
        )

        # FEATURE 3

        feature_id = 'pav_time'
        title = 'PAV runtime'
        feature_params = {'committee_size': 10}
        experiment.compute_feature(feature_id=feature_id, feature_params=feature_params)

        experiment.print_map(
            feature_id=feature_id, column_id='value', adjust=True,
            saveas=f'final_egg/features/{feature_id}/{name}_{distance_id}_{feature_id}',
            title=title, title_size=24,
            cmap=mapel.custom_div_cmap(colors=['lavender', 'indigo']),
            show=False, legend=False,
            bbox_inches=Bbox([[0 + 1.25, 0.5], [6.4 - 1.25, 6.4]]),
            ms=40, feature_labelsize=18,
            rounding=0,
            normalizing_func=normalizing_function_pav,
            xticklabels=['0', '4s', '18s', '80s', '6m', '25m']
        )

        # # ### ### ###
        #
        experiment_id = f'cohesiveness_egg/{name}'
        experiment = mapel.prepare_experiment(experiment_id=experiment_id,
                                              instance_type='approval', clean=False,
                                              distance_id=distance_id)
        # PREPARE MAP

        experiment.prepare_elections()
        experiment.compute_distances(distance_id=distance_id, printing=False)
        experiment.embed(algorithm='spring', num_iterations=2000)
        experiment.print_map(
            saveas=f'cohesiveness_egg/raw_maps/{name}_{distance_id}',
            adjust=True, show=True, legend_pos=(0.5, -0.05),
            shading=True, bbox_inches=Bbox([[0 + 0.8, -1], [6.4 - 0.8, 6.4]]),
            textual=['IC 0.5', 'ID 0.5', 'empty', 'full'],
        )

        # FEATURE 4

        feature_id = 'cohesiveness'
        title = 'coh. level'
        feature_params = {'committee_size': 10}
        experiment.compute_feature(feature_id=feature_id, feature_params=feature_params)

        experiment.print_map(
            feature_id=feature_id, column_id='value', adjust=True,
            saveas=f'cohesiveness_egg/features/{feature_id}/{name}_{distance_id}_{feature_id}',
            title=title, title_size=24,
            show=False, legend=False,
            bbox_inches=Bbox([[0 + 1.25, 0.5], [6.4 - 1.25, 6.4]]),
            ms=40, feature_labelsize=20,
            xticklabels=['0', '2', '4', '6', '8', '10'],
            ticks_pos=[0.05, 0.23, 0.41, 0.59, 0.77, 0.95],
            cmap=mapel.custom_div_cmap(
                colors=["green", "lightgreen", "yellow", "orange",
                        "red", "purple", "orchid", "dodgerblue", "blue", "darkblue", "black"],
                num_colors=11)
        )
